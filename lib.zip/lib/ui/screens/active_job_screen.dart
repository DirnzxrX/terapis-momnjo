import 'package:flutter/material.dart';
import 'dart:async';
import 'package:therapist_momnjo/data/api_service.dart';

class ActiveJobScreen extends StatefulWidget {
  const ActiveJobScreen({Key? key}) : super(key: key);

  @override
  State<ActiveJobScreen> createState() => _ActiveJobScreenState();
}

class _ActiveJobScreenState extends State<ActiveJobScreen> {
  final Color primaryPink = const Color(0xFFF48FB1);

  Map<String, dynamic>? _bookingData;
  bool _isDataLoaded = false;
  bool _isApiLoading = false; 

  String _idTransaksiAsli = '';
  String _idBookingAsli = '';
  String _productName = '';

  Timer? _uiTimer;
  DateTime? _waktuMulaiServer;
  Duration _serverTimeOffset = Duration.zero; // Selisih waktu device vs server
  
  int _secondsElapsed = 0; 
  int _estimatedTotalSeconds = 0; 
  
  bool _hasStarted = false; 
  bool _allowPop = false; 

  List<dynamic> _treatments = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isDataLoaded) {
      final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (args != null) {
        _bookingData = args;
        
        _idTransaksiAsli = args['id_transaksi']?.toString() ?? args['transaksi_id']?.toString() ?? '';
        _idBookingAsli = args['id_booking']?.toString() ?? '';
        _productName = args['product_name']?.toString() ?? '';
        
        _treatments = args['treatments'] ?? args['services'] ?? [];

        if (_treatments.isEmpty) {
          String fallbackName = args['treatment_summary'] ?? args['treatment_name'] ?? _productName;
          if (fallbackName.isNotEmpty && fallbackName.toLowerCase() != 'treatment' && fallbackName.toLowerCase() != 'layanan') {
            var fallbackDur = args['duration'] ?? args['durasi'];
            int parsedDur = _parseDuration(fallbackDur, fallbackName);
            // Defaulting id_detail ke yang ada di root args jika tersedia
            _treatments = [{
              'id_detail': args['id_detail'],
              'name': fallbackName.trim(), 
              'qty': 1, 
              'durasi': parsedDur
            }];
          }
        }

        if (_treatments.isNotEmpty) {
          int totalMenit = 0;
          for (var item in _treatments) {
            int dur = 60;
            int qty = 1;
            if (item is Map) {
              dur = _parseDuration(item['duration'] ?? item['durasi'], _getRobustTreatmentName(item));
              qty = int.tryParse(item['qty']?.toString() ?? '1') ?? 1;
            } else {
              dur = _parseDuration(null, item.toString());
            }
            totalMenit += (dur * qty);
          }
          _estimatedTotalSeconds = totalMenit * 60; 
        } else {
          var rootDur = args['duration'] ?? args['durasi'];
          _estimatedTotalSeconds = _parseDuration(rootDur, _productName.isNotEmpty ? _productName : '60 min') * 60;
        }

        // Ambil data dari server sebagai sumber kebenaran (Source of Truth)
        _syncWithServer();
      }
      _isDataLoaded = true;
    }
  }

  /// Sinkronisasi dengan get_service.php untuk mendapatkan timestamp akurat
  Future<void> _syncWithServer() async {
    setState(() => _isApiLoading = true);
    try {
      final api = ApiService();
      // Pastikan ApiService Anda memiliki method ini untuk memanggil get_service.php?scope=active
      final response = await api.getActiveServices(); 
      
      if (response != null && response['success'] == true) {
        final data = response['data'];
        if (data != null && data['server_time'] != null) {
          final serverTime = DateTime.parse(data['server_time']);
          _serverTimeOffset = serverTime.difference(DateTime.now());

          final items = data['items'] as List<dynamic>? ?? [];
          
          // Cari item yang sesuai dengan transaksi ini
          final currentService = items.firstWhere(
            (item) => item['id_transaksi'] == _idTransaksiAsli,
            orElse: () => null
          );

          if (currentService != null && currentService['is_in_progress'] == true) {
             _hasStarted = true;
             if (currentService['waktu_mulai_iso'] != null) {
               _waktuMulaiServer = DateTime.parse(currentService['waktu_mulai_iso']);
               _startUiTimer();
             } else {
               _secondsElapsed = currentService['elapsed_seconds'] ?? 0;
             }
          }
        }
      }
    } catch (e) {
      debugPrint("Gagal sync dengan server: $e");
    } finally {
      if (mounted) setState(() => _isApiLoading = false);
    }
  }

  // Helper untuk mendapatkan waktu sekarang menyesuaikan waktu server
  DateTime get _currentServerTime => DateTime.now().add(_serverTimeOffset);

  void _startUiTimer() {
    _uiTimer?.cancel(); 
    _uiTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && _waktuMulaiServer != null) {
        setState(() {
          final diff = _currentServerTime.difference(_waktuMulaiServer!).inSeconds;
          _secondsElapsed = diff > 0 ? diff : 0;
        });
      }
    });
  }

  @override
  void dispose() {
    _uiTimer?.cancel();
    super.dispose();
  }

  String _getRobustTreatmentName(dynamic item) {
    String pName = '';
    if (item is Map) {
      pName = (item['product_name'] ?? item['name'] ?? item['treatment_name'] ?? item['deskripsi'] ?? item['nama_layanan'] ?? '').toString().trim();
    } else {
      pName = item?.toString().trim() ?? '';
    }

    if (pName.isEmpty) pName = _productName.trim();
    if (pName.isEmpty) pName = _bookingData?['treatment_name']?.toString().trim() ?? '';
    if (pName.isEmpty) pName = _bookingData?['treatment_summary']?.toString().trim() ?? '';
    
    return pName.isEmpty ? 'Treatment' : pName;
  }

  int _parseDuration(dynamic durValue, String fallbackName) {
    if (durValue != null && durValue.toString().trim().isNotEmpty) {
      String durStr = durValue.toString().toLowerCase().trim();
      int? parsed = int.tryParse(durStr);
      if (parsed != null && parsed > 0) return parsed;
      
      final RegExp regExp = RegExp(r'(\d+)');
      final match = regExp.firstMatch(durStr);
      if (match != null) {
         int extracted = int.tryParse(match.group(1) ?? '60') ?? 60;
         if (extracted > 0) return extracted;
      }
    }
    
    final RegExp regExpName = RegExp(r'(\d+)\s*(min|menit|mins)', caseSensitive: false);
    final matchName = regExpName.firstMatch(fallbackName);
    if (matchName != null) {
       return int.tryParse(matchName.group(1) ?? '60') ?? 60;
    }
    return 60; 
  }

  Future<void> _handleTimerAction() async {
    if (!_hasStarted) {
      setState(() => _isApiLoading = true);
      
      final api = ApiService();
      dynamic firstTreatment = _treatments.isNotEmpty ? _treatments[0] : _bookingData;
      
      // Ambil id_detail sebagai identifier utama sesuai arsitektur baru
      String? targetIdDetail;
      if (firstTreatment is Map && firstTreatment['id_detail'] != null) {
        targetIdDetail = firstTreatment['id_detail'].toString();
      } else if (_bookingData?['id_detail'] != null) {
        targetIdDetail = _bookingData!['id_detail'].toString();
      }

      if (targetIdDetail == null || _idTransaksiAsli.isEmpty) {
        setState(() => _isApiLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Error: ID Detail atau Transaksi tidak ditemukan.", style: TextStyle(color: Colors.white)), backgroundColor: Colors.red),
        );
        return;
      }

      // Pastikan method updateJobStatus Anda sudah dimodifikasi untuk menerima idDetail
      final result = await api.updateJobStatus(
        idTransaksi: _idTransaksiAsli,
        idDetail: targetIdDetail,
        action: 'start',
      );
      
      if (result['success'] == true || result['status'] == 'success') {
        // Setelah sukses start, tarik ulang data dari server untuk mendapatkan waktu_mulai_iso
        await _syncWithServer();
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Treatment resmi dimulai", style: TextStyle(color: Colors.white)), backgroundColor: Colors.green, duration: Duration(seconds: 1)),
        );
      } else {
        setState(() => _isApiLoading = false);
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text("Gagal Memulai", style: TextStyle(color: Colors.red)),
            content: Text(result['message'] ?? 'Error tidak diketahui saat menghubungi server.'),
            actions: [
              TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text("Tutup", style: TextStyle(color: Colors.grey)))
            ],
          )
        );
      }
    } 
  }

  void _showFinishDialog() async {
    bool? isFinishSuccess = await showDialog<bool>(
      context: context,
      barrierDismissible: false, 
      builder: (BuildContext dialogContext) { 
        return StatefulBuilder(
          builder: (BuildContext stateContext, StateSetter setDialogState) { 
            return AlertDialog(
              title: const Text("Selesaikan Treatment?"),
              content: _isApiLoading 
                  ? const Row(
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(width: 16),
                        Text("Memproses ke server..."),
                      ],
                    )
                  : const Text("Pastikan semua tindakan untuk treatment ini telah selesai dikerjakan."),
              actions: [
                if (!_isApiLoading)
                  TextButton(
                    onPressed: () => Navigator.of(dialogContext).pop(false), 
                    child: const Text("Batal", style: TextStyle(color: Colors.grey))
                  ),
                ElevatedButton(
                  onPressed: _isApiLoading ? null : () async {
                    setDialogState(() => _isApiLoading = true); 
                    
                    final api = ApiService();
                    bool jobHasError = false;
                    String errorMessage = "";

                    // Menyelesaikan SEMUA treatment menggunakan id_detail
                    for (int i = 0; i < _treatments.length; i++) {
                      var item = _treatments[i];
                      
                      bool alreadyDoneFromBackend = false;
                      String? currentIdDetail;

                      if (item is Map) {
                         var dVal = item['is_done'];
                         alreadyDoneFromBackend = (dVal == true || dVal == 'true' || dVal == 1 || dVal == '1');
                         currentIdDetail = item['id_detail']?.toString();
                      }

                      if (alreadyDoneFromBackend) continue; 
                      if (currentIdDetail == null) {
                         currentIdDetail = _bookingData?['id_detail']?.toString();
                      }

                      if (currentIdDetail != null) {
                         final result = await api.updateJobStatus(
                            idTransaksi: _idTransaksiAsli,
                            idDetail: currentIdDetail,
                            action: 'finish'
                         );
                         if (result['success'] != true) {
                            jobHasError = true;
                            errorMessage = result['message'] ?? 'Gagal menyelesaikan treatment ke-${i+1}';
                            break; 
                         }
                      }
                    }

                    if (mounted) setDialogState(() => _isApiLoading = false);

                    if (!jobHasError) {
                      Navigator.of(dialogContext).pop(true);
                    } else {
                      Navigator.of(dialogContext).pop(false);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(errorMessage), backgroundColor: Colors.red),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: primaryPink),
                  child: const Text("Ya, Selesai", style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          }
        );
      }
    );

    if (isFinishSuccess == true) {
      _uiTimer?.cancel();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Treatment berhasil diselesaikan!"), backgroundColor: Colors.green),
      );

      setState(() {
        _allowPop = true;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.of(context).canPop()) {
          Navigator.of(context).pop({
            'action': 'finish_treatment',
            'durasi_aktual': _secondsElapsed,
            'is_fully_completed': true,
          });
        }
      });
    }
  }

  String _formatDuration(int totalSeconds) {
    if (totalSeconds < 0) totalSeconds = 0;
    int hours = totalSeconds ~/ 3600;
    int minutes = (totalSeconds % 3600) ~/ 60;
    int seconds = totalSeconds % 60;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  String _formatRemaining(int elapsed, int total) {
    int remaining = total - elapsed;
    if (remaining < 0) remaining = 0;
    int minutes = remaining ~/ 60;
    int seconds = remaining % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  void _saveStateAndPop() {
    if (_allowPop) return; 
    _uiTimer?.cancel();
    
    setState(() {
      _allowPop = true;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && Navigator.of(context).canPop()) {
        Navigator.of(context).pop({
          'action': 'back',
          'is_fully_completed': false,
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _allowPop, 
      onPopInvoked: (didPop) {
        if (didPop) return;
        _saveStateAndPop(); 
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFAFAFA),
        appBar: AppBar(
          backgroundColor: primaryPink,
          elevation: 0,
          title: const Text('Job Aktif', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: _saveStateAndPop,
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Stack(
                  children: [
                    Container(height: 100, width: double.infinity, color: primaryPink),
                    Column(
                      children: [
                        _buildHeaderInfo(),
                        const SizedBox(height: 16),
                        _buildTimerCard(),
                        const SizedBox(height: 24),
                        _buildProgressSection(), 
                      ],
                    ),
                  ],
                ),
              ),
            ),
            _buildBottomActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderInfo() {
    String rawCustomerName = _bookingData?['customer_name']?.toString() ?? '';
    if (rawCustomerName.trim().isEmpty) {
      rawCustomerName = _bookingData?['customer_fullname']?.toString() ?? ''; 
    }
    final String idBooking = _bookingData?['id_booking']?.toString() ?? '';
    if (rawCustomerName.trim().isEmpty) rawCustomerName = idBooking;
    
    final String namaKlien = (rawCustomerName.trim().isNotEmpty && rawCustomerName != '-') ? rawCustomerName : 'Klien Tanpa Nama';
    final String labelLayanan = _treatments.isNotEmpty ? '${_treatments.length} Layanan' : _productName;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(namaKlien, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(labelLayanan, style: const TextStyle(color: Colors.white, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimerCard() {
    String statusText = !_hasStarted ? 'Menunggu Dimulai' : 'Durasi Berjalan';
    Color statusColor = !_hasStarted ? Colors.orange.shade700 : Colors.green.shade600;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(statusText, style: TextStyle(fontSize: 12, color: statusColor, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(
                _formatDuration(_secondsElapsed),
                style: TextStyle(
                  fontSize: 28, 
                  fontWeight: FontWeight.bold, 
                  color: (!_hasStarted) ? Colors.grey.shade400 : Colors.black87
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text('Sisa Estimasi', style: TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.w500)),
              const SizedBox(height: 8),
              Text(
                _formatRemaining(_secondsElapsed, _estimatedTotalSeconds),
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.grey),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProgressSection() {
    if (_treatments.isEmpty) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Daftar Treatment', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          for (int i = 0; i < _treatments.length; i++)
            _buildTreatmentCard(_treatments[i]),
        ],
      ),
    );
  }

  Widget _buildTreatmentCard(dynamic item) {
    String name = _getRobustTreatmentName(item); 
    String qty = item is Map ? (item['qty']?.toString() ?? '1') : '1';
    int durasiMenit = item is Map ? _parseDuration(item['duration'] ?? item['durasi'], name) : _parseDuration(null, name);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.grey.shade200),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 4, offset: const Offset(0, 2))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black87)),
            const SizedBox(height: 4),
            Text('Jumlah: $qty x  •  Durasi: $durasiMenit menit', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomActions() {
    return Container(
      padding: const EdgeInsets.all(20),
      color: Colors.white,
      child: Row(
        children: [
          if (!_hasStarted)
            Expanded(
              child: OutlinedButton(
                onPressed: _isApiLoading ? null : _handleTimerAction,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.green.shade600, width: 2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isApiLoading
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.play_arrow, color: Colors.green.shade600, size: 18),
                          const SizedBox(width: 6),
                          Text('Mulai', style: TextStyle(color: Colors.green.shade600, fontWeight: FontWeight.bold)),
                        ],
                      ),
              ),
            ),
          if (!_hasStarted) const SizedBox(width: 16),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: (!_hasStarted || _isApiLoading) ? null : _showFinishDialog,
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryPink,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Selesai Treatment', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],  
      ),
    );
  }
}