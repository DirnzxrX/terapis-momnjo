import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:therapist_momnjo/data/api_service.dart';
import 'package:therapist_momnjo/ui/screens/sop_panduan_screen.dart';
import 'settings_screen.dart';
import 'data_diri_screen.dart'; 

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final Color primaryPink = const Color(0xFFE8647C); 
  
  // URL global dari ApiService
  final String baseImageUrl = ApiService.baseImageUrl;

  // --- STATE VARIABLE UNTUK DATA DINAMIS ---
  String _therapistName = "Memuat...";
  String _therapistId = "-";
  String _gerai = "Memuat..."; 
  
  // State untuk Rating dan Review
  String _rating = "0.0";
  String _reviewCount = "0";
  String _avatarUrl = ""; 
  
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  // --- FUNGSI MENGAMBIL DATA DARI API ---
  Future<void> _loadProfileData() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
      });
    }

    try {
      // 1. Tampilkan data dari SharedPreferences dulu sebagai cache cepat
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String name = prefs.getString('nama_lengkap') ?? prefs.getString('fullname') ?? 'Terapis Mom n Jo';
      String id = prefs.getString('username') ?? prefs.getString('id_terapis') ?? 'TRP-000';
      String branch = prefs.getString('gerai') ?? prefs.getString('branch') ?? '-'; 
      
      // 🔥 SABUK PENGAMAN 1: Load Foto dari Cache dengan Anti Mixed-Content
      String cachedFoto = prefs.getString('foto_profil') ?? '';
      if (cachedFoto.isNotEmpty && cachedFoto != "null" && cachedFoto != "-") {
         if (!cachedFoto.startsWith('http')) {
           cachedFoto = "$baseImageUrl/$cachedFoto";
         }
         cachedFoto = cachedFoto.replaceFirst('http://', 'https://'); // Paksa HTTPS
      }

      if (mounted) {
        setState(() {
          _therapistName = name.isEmpty ? id : name; 
          _therapistId = id;
          _gerai = branch; 
          _avatarUrl = cachedFoto;
        });
      }

      // 2. Panggil API secara paralel
      final apiService = ApiService();
      final responses = await Future.wait([
        apiService.getProfile(),
        apiService.getDataDiri(),
      ]);

      final profileResponse = responses[0];
      final dataDiriResponse = responses[1];

      if (mounted) {
        setState(() {
          // VARIABEL SEMENTARA UNTUK MENAMPUNG FOTO
          String rawFoto = "";

          // --- A. UPDATE DARI PROFILE API (Nama, Rating) ---
          if (profileResponse['success'] == true || profileResponse['status'] == 'success') {
            final data = profileResponse['data'];
            
            String fetchedName = data['nama_lengkap']?.toString() ?? '';
            if (fetchedName.trim().isEmpty) {
              fetchedName = data['username']?.toString() ?? _therapistName;
            }
            
            _therapistName = fetchedName;
            _therapistId = data['username'] ?? _therapistId;

            var rawRating = data['average_rating'];
            if (rawRating != null) {
               double? parsedRating;
               if (rawRating is num) {
                 parsedRating = rawRating.toDouble();
               } else {
                 parsedRating = double.tryParse(rawRating.toString());
               }
               _rating = parsedRating != null ? parsedRating.toStringAsFixed(1) : '0.0';
            } else {
               _rating = '0.0';
            }

            _reviewCount = data['total_reviews']?.toString() ?? '0';

            // Cek jika API profile punya gerai (fallback awal)
            String fetchedGeraiProfile = data['gerai']?.toString() ?? data['branch']?.toString() ?? '';
            if (fetchedGeraiProfile.trim().isNotEmpty && fetchedGeraiProfile != 'null') {
              _gerai = fetchedGeraiProfile;
            }

            // Fallback foto jika di getDataDiri tidak ada
            rawFoto = data['avatar_url']?.toString() ?? data['avatar']?.toString() ?? "";
          }

          // --- B. UPDATE DARI DATA DIRI API (Gerai & Foto Profil Utama) ---
          if (dataDiriResponse['success'] == true || dataDiriResponse['status'] == 'success') {
            dynamic rawDataDiri = dataDiriResponse['data'];
            Map<String, dynamic> safeDataDiri = {};
            
            // Antisipasi jika backend kirim array atau object
            if (rawDataDiri is List && rawDataDiri.isNotEmpty) {
              safeDataDiri = rawDataDiri[0];
            } else if (rawDataDiri is Map) {
              safeDataDiri = Map<String, dynamic>.from(rawDataDiri);
            }

            String fetchedGeraiDataDiri = safeDataDiri['gerai']?.toString() ?? safeDataDiri['branch']?.toString() ?? '';
            
            if (fetchedGeraiDataDiri.trim().isNotEmpty && fetchedGeraiDataDiri != 'null' && fetchedGeraiDataDiri != '-') {
              _gerai = fetchedGeraiDataDiri; // Timpa dengan data dari get_data_diri.php
            }

            // Ambil foto profil dari Data Diri (prioritas tertinggi karena fitur upload ada di sini)
            String fetchFotoDiri = safeDataDiri['foto_profil']?.toString() ?? safeDataDiri['foto']?.toString() ?? safeDataDiri['image']?.toString() ?? "";
            if (fetchFotoDiri.isNotEmpty && fetchFotoDiri != "null") {
              rawFoto = fetchFotoDiri;
            }
          }

          // 🔥 SABUK PENGAMAN 2: PROSES KOMPILASI FOTO DARI SERVER ---
          String remoteFoto = "";
          if (rawFoto.isNotEmpty && rawFoto != "null" && rawFoto != "-") {
             if (!rawFoto.startsWith('http')) {
               remoteFoto = "$baseImageUrl/$rawFoto"; 
             } else {
               remoteFoto = rawFoto;
             }
             // Tangkal Mixed Content dari server
             remoteFoto = remoteFoto.replaceFirst('http://', 'https://');
          }

          if (remoteFoto.isNotEmpty) {
            // Bypass cache dengan millis timestamp agar perbaruan foto langsung terlihat
            _avatarUrl = "$remoteFoto?v=${DateTime.now().millisecondsSinceEpoch}";
            prefs.setString('foto_profil', rawFoto); // Simpan nama filenya ke cache
          }

          // Bersihkan text jika gerai tetap gagal diload
          if (_gerai == "Memuat..." || _gerai.trim().isEmpty) {
            _gerai = "-";
          }

          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          if (_therapistName == "Memuat...") _therapistName = "Terapis Mom n Jo";
          if (_gerai == "Memuat...") _gerai = "-";
          _isLoading = false;
        });
      }
    }
  }

  // --- LOGIKA LOGOUT ---
  void _handleLogout(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false, 
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Konfirmasi Keluar', style: TextStyle(fontWeight: FontWeight.bold)),
          content: const Text('Apakah Anda yakin ingin mengakhiri sesi dan keluar dari aplikasi?'),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext), 
              child: Text('Batal', style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(dialogContext);
                await ApiService().logout();

                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(
                    context, 
                    '/login', 
                    (Route<dynamic> route) => false, 
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade600,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('Ya, Keluar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/background.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent, 
        appBar: AppBar(
          backgroundColor: Colors.transparent, 
          elevation: 0,
          automaticallyImplyLeading: false, 
          title: const Text(
            'Profil Saya',
            style: TextStyle(
              color: Colors.black87,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
        ),
        body: RefreshIndicator(
          onRefresh: _loadProfileData,
          color: primaryPink,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              children: [
                const SizedBox(height: 10),
                _buildProfileHeader(),
                const SizedBox(height: 16),
                _buildDetailInfo(),
                const SizedBox(height: 16),
                _buildMenuList(context),
                const SizedBox(height: 40), 
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- WIDGET BUILDERS ---

  Widget _buildProfileHeader() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.pink.shade50,
            ),
            child: CircleAvatar(
              radius: 36,
              backgroundColor: Colors.grey.shade200,
              // Fallback gambar jika error 404 dari server
              onBackgroundImageError: (exception, stackTrace) {
                 if (_avatarUrl.isNotEmpty && !_avatarUrl.contains('ui-avatars')) {
                   WidgetsBinding.instance.addPostFrameCallback((_) {
                     if (mounted) {
                       setState(() {
                         _avatarUrl = ""; // Kembalikan ke foto inisial
                       });
                     }
                   });
                 }
              },
              backgroundImage: _avatarUrl.isNotEmpty 
                  ? NetworkImage(_avatarUrl)
                  : NetworkImage('https://ui-avatars.com/api/?name=${Uri.encodeComponent(_therapistName.isNotEmpty ? _therapistName : "Terapis")}&background=E8647C&color=fff'), 
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _isLoading 
            ? const Center(child: CircularProgressIndicator()) 
            : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _therapistName, 
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  'Terapis ID: $_therapistId', 
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 18),
                    const SizedBox(width: 4),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '$_rating ', 
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          TextSpan(
                            text: '($_reviewCount review)', 
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailInfo() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildInfoRow('Gerai', _gerai), 
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child: Text(
            label,
            style: TextStyle(fontSize: 13, color: Colors.grey.shade600, fontWeight: FontWeight.w500),
          ),
        ),
        Expanded(
          flex: 3,
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMenuList(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const SizedBox(height: 8), 
          
          _buildMenuItem(Icons.person_outline, 'Data Diri', () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DataDiriScreen()),
            ).then((_) {
              // Refresh otomatis jika gambar diubah di layar Data Diri
              _loadProfileData(); 
            });
          }),
          _buildMenuDivider(),
          
          _buildMenuItem(Icons.menu_book_outlined, 'SOP & Panduan', () {
             Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SopPanduanScreen()),);
          }),
          _buildMenuDivider(),
          
          _buildMenuItem(Icons.settings_outlined, 'Pengaturan', () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SettingsScreen()),
            ).then((_) {
              // Refresh otomatis jika gambar diubah di layar Settings
              _loadProfileData(); 
            });
          }),
          _buildMenuDivider(),
          
          // TOMBOL KELUAR
          _buildMenuItem(
            Icons.logout_outlined, 
            'Keluar', 
            () => _handleLogout(context),
            textColor: Colors.red.shade700,
            iconColor: Colors.red.shade700,
            showTrailing: false, 
          ),
          
          const SizedBox(height: 8), 
        ],
      ),
    );
  }

  Widget _buildMenuItem(IconData icon, String title, VoidCallback onTap, {Color? textColor, Color? iconColor, bool showTrailing = true}) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
      dense: true, 
      leading: Icon(icon, color: iconColor ?? Colors.grey.shade700, size: 22),
      title: Text(
        title,
        style: TextStyle( 
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: textColor ?? Colors.black87,
        ),
      ),
      trailing: showTrailing ? Icon(Icons.chevron_right, color: Colors.grey.shade400, size: 20) : null,
      onTap: onTap, 
    );
  }

  Widget _buildMenuDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Divider(color: Colors.grey.shade200, height: 1),
    );
  }
}