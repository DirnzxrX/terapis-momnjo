import 'dart:convert';
import 'dart:async'; 
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; 
import 'package:shared_preferences/shared_preferences.dart';
import 'package:therapist_momnjo/data/api_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // --- STATE VARIABLES ---
  String _namaTerapis = 'Terapis'; 
  String _fotoProfile = ''; 
  int _bookingHariIni = 0;
  int _selesai = 0;
  Map<String, dynamic>? _nextBooking;
  bool _isLoading = true;

  // STATE STATUS KERJA
  bool _isOnDuty = false; 

  // STATE NOTIFIKASI
  bool _hasNewNotification = false;
  List<Map<String, String>> _notifications = [];

  // --- STATE CAROUSEL ---
  List<String> _carouselImages = [];
  // Mulai dari indeks yang besar agar bisa langsung digeser ke kiri (infinite loop)
  int _currentCarouselIndex = 10000; 
  late PageController _pageController;
  Timer? _carouselTimer;

  // Konstanta Warna
  final Color textDarkBrown = const Color(0xFF4A332B);
  final Color primaryPeach = const Color(0xFFECA898);
  final Color goldBrown = const Color(0xFFB08D57);

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _currentCarouselIndex, viewportFraction: 0.95);
    _loadData();
  }

  @override
  void dispose() {
    _carouselTimer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _startCarouselTimer() {
    _carouselTimer?.cancel();
    // Hanya jalankan auto-play jika gambar lebih dari 1
    if (_carouselImages.length > 1) {
      _carouselTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
        if (_pageController.hasClients) {
          _pageController.nextPage(
            duration: const Duration(milliseconds: 500),
            curve: Curves.fastOutSlowIn,
          );
        }
      });
    }
  }

  // --- FUNGSI LOAD DATA DARI LOKAL & API ---
  Future<void> _loadData() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      
      String? namaSimpanan = prefs.getString('nama_lengkap') ?? prefs.getString('fullname');
      String? usernameSimpanan = prefs.getString('username');
      String namaTampil = 'Terapis'; 
      
      // 🚀 PERUBAHAN: Status duty lokal dihapus
      // bool isOnDutySimpanan = prefs.getBool('is_on_duty') ?? false;

      if (namaSimpanan != null && namaSimpanan.trim().isNotEmpty) {
        namaTampil = namaSimpanan;
      } else if (usernameSimpanan != null && usernameSimpanan.trim().isNotEmpty) {
        namaTampil = usernameSimpanan; 
      }
      
      // 🛡️ SABUK PENGAMAN 1: Load Foto dari Cache dengan Anti Mixed-Content
      String? fotoSimpanan = prefs.getString('foto_profil') ?? prefs.getString('foto'); 
      if (fotoSimpanan != null && fotoSimpanan.isNotEmpty && fotoSimpanan != "null" && fotoSimpanan != "-") {
         if (!fotoSimpanan.startsWith('http')) {
           fotoSimpanan = "${ApiService.baseImageUrl}/$fotoSimpanan";
         }
         fotoSimpanan = fotoSimpanan.replaceFirst('http://', 'https://'); // Paksa HTTPS
      }

      final api = ApiService();
      final String todayStr = DateFormat('yyyy-MM-dd').format(DateTime.now());
      int todayJobsCount = 0;
      int todayHistoryCount = 0;

      // FETCH CAROUSEL
      _fetchCarousel(api);

      // 1. FETCH JOBS
      final jobsResponse = await api.getActiveJobs(); 
      Map<String, dynamic>? nextBook;
      List<Map<String, String>> newNotifs = [];
      bool hasNewNotif = false;
      
      if (jobsResponse['success'] == true && jobsResponse['data'] != null) {
        List jobs = jobsResponse['data'];
        List openJobs = [];
        
        for (var job in jobs) {
          final String status = (job['status'] ?? job['booking_status'] ?? '').toString().toLowerCase().trim();
          final String startTime = job['start_time']?.toString() ?? '';
          
          if (startTime.startsWith(todayStr)) {
            todayJobsCount++;
          }

          if (!['close', 'closed', 'completed'].contains(status)) {
            openJobs.add(job);
          }
        }

        if (openJobs.isNotEmpty) {
          openJobs.sort((a, b) {
            DateTime timeA = DateTime.tryParse(a['start_time']?.toString() ?? '') ?? DateTime(2000);
            DateTime timeB = DateTime.tryParse(b['start_time']?.toString() ?? '') ?? DateTime(2000);
            return timeA.compareTo(timeB); 
          });

          nextBook = openJobs.first; 
          
          final namaKlien = nextBook?['customer_name'] ?? 'Klien';
          final deskripsi = nextBook?['treatment_summary'] ?? 'Treatment';
          final rawJam = nextBook?['start_time']?.toString() ?? '--:--';
          
          newNotifs.add({
            'title': 'Tugas Baru Masuk!',
            'body': 'Anda ditugaskan untuk melakukan $deskripsi kepada $namaKlien pada pukul ${_formatTime(rawJam)}.',
            'time': 'Baru saja',
          });
          hasNewNotif = true;
        }
      }

      // 2. FETCH HISTORY
      final historyResponse = await api.getHistoryList();
      if (historyResponse['status'] == 'success' || historyResponse['success'] == true) {
         List historyList = historyResponse['data'] ?? [];
         for(var item in historyList) {
            String tgl = item['start_time'] ?? item['jadwal'] ?? item['date'] ?? '';
            if (tgl.startsWith(todayStr)) {
               todayHistoryCount++;
            }
         }
      }

      // 3. FETCH PROFILE & DATA DIRI (Untuk Foto Akurat)
      try {
        final responses = await Future.wait([
          api.getProfile(),
          api.getDataDiri(),
        ]);
        
        final profileResponse = responses[0];
        final dataDiriResponse = responses[1];
        String rawFoto = "";

        if (profileResponse['success'] == true || profileResponse['status'] == 'success') {
          final data = profileResponse['data'];
          
          String fetchedName = data['nama_lengkap']?.toString() ?? '';
          if (fetchedName.trim().isEmpty) {
            fetchedName = data['username']?.toString() ?? namaTampil;
          }
          namaTampil = fetchedName;
          
          rawFoto = data['avatar_url']?.toString() ?? data['avatar']?.toString() ?? "";
        }

        if (dataDiriResponse['success'] == true || dataDiriResponse['status'] == 'success') {
          dynamic rawDataDiri = dataDiriResponse['data'];
          Map<String, dynamic> safeDataDiri = {};
          if (rawDataDiri is List && rawDataDiri.isNotEmpty) {
            safeDataDiri = rawDataDiri[0];
          } else if (rawDataDiri is Map) {
            safeDataDiri = Map<String, dynamic>.from(rawDataDiri);
          }

          String fetchFotoDiri = safeDataDiri['foto_profil']?.toString() ?? safeDataDiri['foto']?.toString() ?? safeDataDiri['image']?.toString() ?? "";
          if (fetchFotoDiri.isNotEmpty && fetchFotoDiri != "null") {
            rawFoto = fetchFotoDiri;
          }
        }

        // 🛡️ SABUK PENGAMAN 2: Tangkal Mixed Content API Profil
        if (rawFoto.isNotEmpty && rawFoto != "null" && rawFoto != "-") {
           String remoteFoto = "";
           if (!rawFoto.startsWith('http')) {
             remoteFoto = "${ApiService.baseImageUrl}/$rawFoto"; 
           } else {
             remoteFoto = rawFoto;
           }
           remoteFoto = remoteFoto.replaceFirst('http://', 'https://'); // Paksa HTTPS
           
           // Tambahkan Timestamp agar cache memuat ulang gambar baru
           fotoSimpanan = "$remoteFoto?v=${DateTime.now().millisecondsSinceEpoch}";
           await prefs.setString('foto_profil', rawFoto);
        }
      } catch (e) {}

      // 🚀 4. PERBAIKAN: FETCH STATUS ABSENSI DARI SERVER (Single Source of Truth)
      bool currentDutyStatus = false;
      try {
        final attendanceResponse = await api.getAttendanceHistory();
        if (attendanceResponse['success'] == true && attendanceResponse['data'] != null) {
          final dataMap = attendanceResponse['data'] as Map<String, dynamic>;
          final List<dynamic> rawData = dataMap['history'] ?? [];
          
          if (rawData.isNotEmpty) {
            final latestRecord = rawData.first as Map<String, dynamic>;
            final checkInMap = latestRecord['check_in'] as Map<String, dynamic>?;
            final checkOutMap = latestRecord['check_out'] as Map<String, dynamic>?;
            
            bool hasCheckIn = checkInMap != null && checkInMap['waktu'] != null;
            bool hasCheckOut = checkOutMap != null && checkOutMap['waktu'] != null;
            
            // Jika ada check_in tapi belum check_out, berarti On Duty
            if (hasCheckIn && !hasCheckOut) {
              currentDutyStatus = true;
            }
          }
        }
      } catch (e) {
        debugPrint("Gagal mengambil status absensi: $e");
      }

      if (mounted) {
        setState(() {
          _namaTerapis = namaTampil;
          _fotoProfile = fotoSimpanan ?? '';
          _isOnDuty = currentDutyStatus; // 🚀 Gunakan data dari server
          _bookingHariIni = todayJobsCount + todayHistoryCount;
          _selesai = todayHistoryCount; 
          _nextBooking = nextBook;
          _notifications = newNotifs;
          _hasNewNotification = hasNewNotif;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // --- FUNGSI AMBIL CAROUSEL DARI API ---
  Future<void> _fetchCarousel(ApiService api) async {
    try {
      final response = await api.getCarousel();
      if ((response['status'] == 'success' || response['success'] == true) && response['data'] != null) {
        
        dynamic responseData = response['data'];
        List dataList = [];
        
        if (responseData is List) {
          dataList = responseData;
        } else if (responseData is Map) {
          dataList = responseData.values.toList();
        }
        
        List<String> loadedImages = [];
        
        for (var item in dataList) {
          if (item is String) {
            // 🛡️ SABUK PENGAMAN 3A: Carousel Array of String
            loadedImages.add(item.replaceFirst('http://', 'https://'));
          } else if (item is Map) {
            String? url = item['image'] ?? item['image_url'] ?? item['banner'] ?? item['file'] ?? item['url'] ?? item['foto'] ?? item['gambar'] ?? item['path'];
            
            if (url == null || url.trim().isEmpty) {
              for (var val in item.values) {
                if (val is String) {
                  String v = val.toLowerCase();
                  if (v.contains('.jpg') || v.contains('.jpeg') || v.contains('.png') || v.contains('.webp')) {
                    url = val;
                    break;
                  }
                }
              }
            }

            if (url != null && url.trim().isNotEmpty) {
              if (!url.startsWith('http')) {
                // Hapus awalan '/' atau 'assets/images/' jika terbawa dari backend
                url = url.replaceAll('assets/images/', '').replaceFirst(RegExp(r'^/'), '');
                url = '${ApiService.baseImageUrl}/$url'; 
              }
              // 🛡️ SABUK PENGAMAN 3B: Carousel Array of Object
              url = url.replaceFirst('http://', 'https://'); // Paksa HTTPS
              loadedImages.add(url);
            }
          }
        }

        if (mounted && loadedImages.isNotEmpty) {
          setState(() {
            _carouselImages = loadedImages;
          });
          _startCarouselTimer();
        }
      }
    } catch (e) {
      debugPrint("Error fetching carousel: $e");
    }
  }

  String _formatTime(String? rawTime) {
    if (rawTime == null || rawTime.isEmpty) return '--:--';
    try {
      if (rawTime.contains(' ')) {
        final timePart = rawTime.split(' ')[1]; 
        final parts = timePart.split(':');
        if (parts.length >= 2) return '${parts[0]}:${parts[1]}';
      }
      if (rawTime.split(':').length >= 2) {
         final parts = rawTime.split(':');
         return '${parts[0]}:${parts[1]}';
      }
      return rawTime;
    } catch (e) {
      return rawTime; 
    }
  }

  void _showNotificationModal(BuildContext context) {
    setState(() {
      _hasNewNotification = false;
    });

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Notifikasi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: textDarkBrown)),
                  if (_notifications.isNotEmpty)
                    TextButton(
                      onPressed: () {
                        setState(() => _notifications.clear());
                        Navigator.pop(context);
                      },
                      child: Text('Bersihkan', style: TextStyle(color: primaryPeach, fontWeight: FontWeight.bold)),
                    )
                ],
              ),
              const SizedBox(height: 10),
              if (_notifications.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30),
                  child: Center(
                    child: Text('Tidak ada pemberitahuan baru.', style: TextStyle(color: Colors.grey.shade500)),
                  ),
                )
              else
                ..._notifications.map((notif) => Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: primaryPeach.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: primaryPeach.withOpacity(0.2)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.assignment_turned_in, size: 16, color: primaryPeach),
                              const SizedBox(width: 8),
                              Text(notif['title']!, style: TextStyle(fontWeight: FontWeight.bold, color: textDarkBrown)),
                            ],
                          ),
                          Text(notif['time']!, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(notif['body']!, style: TextStyle(fontSize: 13, color: textDarkBrown.withOpacity(0.8), height: 1.4)),
                    ],
                  ),
                )).toList(),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/baground2.jpeg'), 
          fit: BoxFit.cover,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent, 
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _loadData, 
            color: primaryPeach,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10),
                  _buildHeader(),
                  const SizedBox(height: 24),
                  _buildStatusCard(),
                  const SizedBox(height: 24),
                  
                  Text(
                    'Ringkasan Hari Ini',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textDarkBrown),
                  ),
                  const SizedBox(height: 12),
                  _buildSummarySection(),
                  const SizedBox(height: 24),
                  
                  Text(
                    'Tugas Berikutnya',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textDarkBrown),
                  ),
                  const SizedBox(height: 12),
                  if (_isLoading)
                    const Center(child: CircularProgressIndicator())
                  else if (_nextBooking != null)
                    _buildNextBookingCard(context)
                  else
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.event_available, size: 40, color: Colors.grey.shade300),
                          const SizedBox(height: 12),
                          Text(
                            'Belum ada pekerjaan',
                            style: TextStyle(color: Colors.grey.shade500, fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 24),
                  
                  // BANNER CAROUSEL API
                  _buildCarouselSection(),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCarouselSection() {
    if (_carouselImages.isEmpty) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.asset(
          'assets/gambar1.jpeg', 
          width: double.infinity,
          height: 220,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => _buildFallbackShimmer()
        ),
      );
    }

    int activeDotIndex = _currentCarouselIndex % _carouselImages.length;

    return Column(
      children: [
        SizedBox(
          height: 220,
          width: double.infinity,
          child: PageView.builder(
            controller: _pageController,
            physics: const BouncingScrollPhysics(parent: PageScrollPhysics()),
            onPageChanged: (index) {
              setState(() {
                _currentCarouselIndex = index;
              });
              if (_carouselImages.length > 1) {
                _startCarouselTimer();
              }
            },
            itemBuilder: (context, index) {
              int actualImageIndex = index % _carouselImages.length;
              
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.network(
                    _carouselImages[actualImageIndex],
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return _buildFallbackShimmer();
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return _buildFallbackShimmer();
                    },
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        if (_carouselImages.length > 1)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _carouselImages.length,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: activeDotIndex == index ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: activeDotIndex == index ? primaryPeach : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildFallbackShimmer() {
    return Container(
      width: double.infinity,
      height: 220,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(16)
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.image_outlined, size: 40, color: Colors.grey.shade400),
          const SizedBox(height: 8),
          Text('Memuat Promosi...', 
            style: TextStyle(color: Colors.grey.shade500, fontSize: 12)
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        CircleAvatar(
          radius: 28,
          backgroundColor: Colors.grey.shade200,
          // --- PENANGANAN ERROR JIKA FOTO SERVER 404 ---
          onBackgroundImageError: (exception, stackTrace) {
             if (_fotoProfile.isNotEmpty && !_fotoProfile.contains('ui-avatars')) {
               WidgetsBinding.instance.addPostFrameCallback((_) {
                 if (mounted) {
                   setState(() {
                     _fotoProfile = ""; // Hapus foto rusak dan panggil UI Avatars
                   });
                 }
               });
             }
          },
          backgroundImage: _fotoProfile.isNotEmpty && _fotoProfile.startsWith('https')
              ? NetworkImage(_fotoProfile)
              : NetworkImage('https://ui-avatars.com/api/?name=${Uri.encodeComponent(_namaTerapis)}&background=ECA898&color=fff') as ImageProvider, 
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Selamat pagi,',
              style: TextStyle(fontSize: 14, color: textDarkBrown.withOpacity(0.8), fontWeight: FontWeight.w500), 
            ),
            Text(
              _namaTerapis,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: textDarkBrown),
            ),
          ],
        ),
        const Spacer(),
        Stack(
          children: [
            IconButton(
              onPressed: () => _showNotificationModal(context),
              icon: Icon(Icons.notifications_none_rounded, size: 28, color: textDarkBrown),
            ),
            if (_hasNewNotification)
              Positioned(
                right: 12,
                top: 12,
                child: Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatusCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Status Kerja', style: TextStyle(fontSize: 14, color: textDarkBrown.withOpacity(0.7), fontWeight: FontWeight.w500)),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // 🛡️ PERBAIKAN: Jika dipencet, bawa mereka ke halaman Manajemen Absensi
                    GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/leave_management').then((_) {
                          _loadData(); // Segarkan data jika status berubah di layar absensi
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: _isOnDuty ? const Color(0xFFE8F5E9) : Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          _isOnDuty ? 'ON DUTY' : 'OFF DUTY', 
                          style: TextStyle(
                            color: _isOnDuty ? const Color(0xFF4CAF50) : Colors.grey.shade600, 
                            fontWeight: FontWeight.bold, 
                            fontSize: 11,
                            letterSpacing: 0.5,
                          )
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Text('08.00 - 17.00', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: textDarkBrown)),
                  ],
                ),
              ],
            ),
          ),
          
          Row(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/leave_management').then((_) {
                    _loadData();
                  });
                },
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: primaryPeach.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.assignment_turned_in, color: primaryPeach, size: 20),
                    ),
                    const SizedBox(height: 6),
                    Text('Absensi', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: textDarkBrown)),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/chat_admin'),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: primaryPeach.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.chat_bubble_outline, color: primaryPeach, size: 20),
                    ),
                    const SizedBox(height: 6),
                    Text('Chat Admin', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: textDarkBrown)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSummarySection() {
    return Row(
      children: [
        Expanded(
          child: _buildSummaryCard(
            _isLoading ? '...' : _bookingHariIni.toString(), 
            'Booking Hari Ini', 
            textDarkBrown,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildSummaryCard(
            _isLoading ? '...' : _selesai.toString(), 
            'Selesai', 
            goldBrown,
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryCard(String value, String label, Color valueColor) {
    return Container(
      height: 110, 
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center, 
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(value, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: valueColor)),
          ),
          const SizedBox(height: 8),
          Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: textDarkBrown.withOpacity(0.8), fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildNextBookingCard(BuildContext context) {
    final rawJam = _nextBooking?['start_time']?.toString() ?? '--:--';
    final jam = _formatTime(rawJam); 
    final namaKlien = _nextBooking?['customer_name'] ?? 'Klien';
    final deskripsi = _nextBooking?['treatment_summary'] ?? 'Treatment';
    
    final roomType = _nextBooking?['room_type']?.toString() ?? '';
    final gerai = _nextBooking?['gerai']?.toString() ?? '';
    String alamat = [gerai, roomType].where((e) => e.isNotEmpty).join(' - ');
    if (alamat.isEmpty) {
      alamat = 'Menunggu konfirmasi lokasi';
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(jam, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: textDarkBrown)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(namaKlien, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: textDarkBrown)),
                Text(deskripsi, style: TextStyle(fontSize: 13, color: textDarkBrown.withOpacity(0.8))),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(Icons.location_on, size: 14, color: textDarkBrown.withOpacity(0.5)),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(alamat, 
                        style: TextStyle(fontSize: 11, color: textDarkBrown.withOpacity(0.6)), 
                        maxLines: 1, 
                        overflow: TextOverflow.ellipsis
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              String roomTypeStr = (_nextBooking?['room_type'] ?? _nextBooking?['type'] ?? _nextBooking?['kategori'] ?? '').toString().toLowerCase();
              bool isHomeService = roomTypeStr.contains('home') || roomTypeStr.contains('kunjungan') || roomTypeStr.isEmpty;
              
              String targetRoute = isHomeService ? '/booking_detail' : '/booking_detail_onsite';

              Navigator.pushNamed(context, targetRoute, arguments: _nextBooking).then((_) {
                _loadData();
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryPeach,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              minimumSize: Size.zero,
              elevation: 0,
            ),
            child: const Row(
              children: [
                Text('Detail', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                SizedBox(width: 2),
                Icon(Icons.chevron_right, size: 14, color: Colors.white),
              ],
            ),
          )
        ],
      ),
    );
  }
}